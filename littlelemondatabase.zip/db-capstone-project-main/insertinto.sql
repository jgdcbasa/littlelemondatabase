INSERT INTO CustomerDetails (CustomerName,Contactdetail,CustomerID) VALUES
('John Doe','phone',1),
('Jane Smith','mobile',2),
('Michael Johnson','phone',3);